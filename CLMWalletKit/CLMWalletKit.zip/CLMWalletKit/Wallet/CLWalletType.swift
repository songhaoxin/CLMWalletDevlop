//
//  CLWalletType.swift
//  EthereumKit
//
//  Created by admin on 2018/8/7.
//  Copyright © 2018年 yuzushioh. All rights reserved.
//

import Foundation

public enum WalletType :UInt8{
    case encryptedKey
    case hierarchicalDeterministicWallet
}
