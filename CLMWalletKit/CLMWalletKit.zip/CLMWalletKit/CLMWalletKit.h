//
//  CLMWalletKit.h
//  CLMWalletKit
//
//  Created by admin on 2018/8/10.
//  Copyright © 2018年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CLMWalletKit.
FOUNDATION_EXPORT double CLMWalletKitVersionNumber;

//! Project version string for CLMWalletKit.
FOUNDATION_EXPORT const unsigned char CLMWalletKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CLMWalletKit/PublicHeader.h>


